# -*- coding: utf-8 -*-
#______________________________ IMPORTS
import sys
from pyrevit import forms

# .NET IMPORTS
import clr
from clr import AddReference
AddReference("System")
from System.Diagnostics.Process import Start
from System.Windows.Window import DragMove
from System.Windows.Input import MouseButtonState
from enum import Enum

AddReference("System")
import System
# Import ETABS
clr.AddReferenceToFileAndPath("C:\Program Files\Computers and Structures\ETABS 18\ETABSv1.dll")
from ETABSv1 import *
 
# Funciones ETABS
floatRef = 0.0
intRef = 1
stringRef = ""
boolRef = True
arrayFloat = System.Array[float]([])
arrayInt = System.Array[int]([])
arrayString = System.Array[str]([])
arrayBool = System.Array[bool]([])

def ObtenerListaNiveles(SapModel):
    [ret, BaseElevation, NumberStories, StoryNames, StoryElevations, 
    StoryHeights, IsMasterStory, SimilarToStory, SpliceAbove, 
    SpliceHeight, color] = SapModel.Story.GetStories_2(floatRef, intRef, arrayString, arrayFloat, 
                                            arrayFloat, arrayBool, arrayString, arrayBool, arrayFloat, arrayInt)
    return StoryNames

def ObtenerLoadPatterns(SapModel):
    ret, NumberNames, MyName = SapModel.LoadPatterns.GetNameList(intRef, arrayString)
    return MyName

def AsignarCargaALosas(SapModel, listaNiveles, loadPattern, carga):
    [ret, NumberNames, 
     nameAreas, labelsAreas, 
     nameLevels ]= SapModel.AreaObj.GetLabelNameList(intRef, arrayString, arrayString, arrayString)
    for nivel in listaNiveles:
        # Obtenemos las losas del nivel
        losasNivel = [nombre for nombre, 
                      label, 
                      nivelLosa in zip(nameAreas, 
                                       labelsAreas, 
                                       nameLevels) if nivelLosa == nivel and label.startswith('F')]
        # Asignamos las cargas a las losas
        for losa in losasNivel:
            ret = SapModel.AreaObj.SetLoadUniform(losa, loadPattern, -carga, 6, True, "Global", eItemType.Objects)
        #print(losasNivel)
# Clase para objeto del listBox
class CheckableItem:
    def __init__(self, name):
        self.name = name
        self.is_checked = False

    @property
    def Name(self):
        return self.name

    @property
    def IsChecked(self):
        return self.is_checked

    @IsChecked.setter
    def IsChecked(self, value):
        self.is_checked = value


# Formulario
class MyWindow(forms.WPFWindow):
    """GUI"""
    def __init__(self, xaml_file_name, SapModel):
        self.form = forms.WPFWindow.__init__(self, xaml_file_name)
        self.main_title.Text = "Asignar Cargas Losas"
        self.txt_NombreModelo.Text = SapModel.GetModelFilename(False)
        ret = SapModel.SetPresentUnits(eUnits.Ton_m_C)
        # Obtenemos la lista de casos
        self.cmb_Casos.ItemsSource = ObtenerLoadPatterns(SapModel)
        self.cmb_Casos.SelectedIndex = 0
        # Crear una lista de ítems CheckableItem desde los niveles
        self.items = [CheckableItem(nivel) for nivel in ObtenerListaNiveles(SapModel)]
        # Asignar la lista al ListBox
        self.lista_Niveles.ItemsSource = self.items
    @property
    def loadCase(self):
        return self.cmb_Casos.SelectedItem
        
    @property
    def carga(self):
        try:
            return float(self.input_carga.Text)
        except:
            print("input_carga debe ser numero!")


    # GUI EVENT HANDLERS:
    def button_close(self,sender,e):
        """Stop application by clicking on a <Close> button in the top right corner."""
        self.Close()

    def Hyperlink_RequestNavigate(self, sender, e):
        """Forwarding for a Hyperlink"""
        Start(e.Uri.AbsoluteUri)

    def header_drag(self,sender,e):
        """Drag window by holding LeftButton on the header."""
        if e.LeftButton == MouseButtonState.Pressed:
            DragMove(self)

    def button_run(self, sender, e):
        """Button action: Rename view with given """
        niveles_seleccionados = [item.Name for item in self.lista_Niveles.ItemsSource if item.IsChecked]
        AsignarCargaALosas(SapModel, niveles_seleccionados, self.loadCase, self.carga)
        self.Close()

    def button_select_none(self, sender, e):
        # Seleccionar todos los ítems
        for item in self.items:
            item.IsChecked = False
        # Actualizar la vista del ListBox
        self.lista_Niveles.Items.Refresh()
    def button_select_all(self, sender, e):
        # Seleccionar todos los ítems
        for item in self.items:
            item.IsChecked = True
        # Actualizar la vista del ListBox
        self.lista_Niveles.Items.Refresh()

if __name__ == '__main__':
    helper = Helper()
    # Intentar obtener el archivo ETABS abierto
    try:
        myETABSObject = helper.GetObject("CSI.ETABS.API.ETABSObject") 
    except:
        print("No se encontró ninguna instancia en ejecución de ETABS.")
        sys.exit(-1)
    SapModel = myETABSObject.SapModel
    MyWindow("AsignarCargaLosas.xaml", SapModel).ShowDialog()



