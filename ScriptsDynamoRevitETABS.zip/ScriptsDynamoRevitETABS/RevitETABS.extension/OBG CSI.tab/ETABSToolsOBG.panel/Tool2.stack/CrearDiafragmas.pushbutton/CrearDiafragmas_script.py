# -*- coding: utf-8 -*-
import sys
import clr

from pyrevit import forms

from enum import Enum
clr.AddReference("System")
import System
 
clr.AddReferenceToFileAndPath("C:\Program Files\Computers and Structures\ETABS 18\ETABSv1.dll")
from ETABSv1 import *
 
#create API helper object
helper = Helper()
# Intentar obtener el archivo ETABS abierto
try:
    myETABSObject = helper.GetObject("CSI.ETABS.API.ETABSObject") 
except:
    print("No se encontró ninguna instancia en ejecución de ETABS.")
    sys.exit(-1)

"""
attributes = dir(helper)
for attr in attributes:
    print(attr)
"""

# Del objeto ETABS, obtenemos el objeto sapModel
SapModel = myETABSObject.SapModel
#print(SapModel.GetModelFilename())
floatRef = 0.0
intRef = 1
stringRef = ""
boolRef = True
arrayFloat = System.Array[float]([])
arrayInt = System.Array[int]([])
arrayString = System.Array[str]([])
arrayBool = System.Array[bool]([])

# Obtenemos la lista de niveles
[ret, BaseElevation, NumberStories, StoryNames, StoryElevations, 
 StoryHeights, IsMasterStory, SimilarToStory, SpliceAbove, 
 SpliceHeight, color] = SapModel.Story.GetStories_2(floatRef, intRef, arrayString, arrayFloat, 
                                         arrayFloat, arrayBool, arrayString, arrayBool, arrayFloat, arrayInt)


# El usuario debe escoger que niveles se van a utilizar
nivelesSeleccionados = forms.SelectFromList.show(StoryNames, button_name='Establecer Niveles', multiselect=True)

# Establecemos el diafragma disconnect para todos los puntos ret, nombresPuntos, coordsX, coordsY, coordsZ 
ret, cantPuntos, nombresPuntos, coordsX, coordsY, coordsZ = SapModel.PointObj.GetAllPoints(intRef, arrayString, arrayFloat, arrayFloat, arrayFloat, "Global")

for nombrePunto in nombresPuntos:
    ret = SapModel.PointObj.SetDiaphragm(nombrePunto, eDiaphragmOption.Disconnect, "")

# Iteramos sobre los niveles seleccionados por el usuario
for nombreNivel in nivelesSeleccionados:
    # Creamos el diafragma rígido para el nivel
    ret = SapModel.Diaphragm.SetDiaphragm(nombreNivel, SemiRigid=False)
    # Obtenemos los puntos del nivel
    [ret, NumberNames, namePointsLevel] = SapModel.PointObj.GetNameListOnStory(nombreNivel, intRef, arrayString)
    # Asignamos el diafragma a cada uno de los puntos
    for nombrePunto in namePointsLevel:
        ret = SapModel.PointObj.SetDiaphragm(nombrePunto, eDiaphragmOption.DefinedDiaphragm, nombreNivel)
        #print(nombrePunto, ": ", ret)

# Imprimir el mensaje de confirmación de creación y asignación de diafragmas
forms.alert('Se han creado y asignado los diafragmas.', exitscript=True)


