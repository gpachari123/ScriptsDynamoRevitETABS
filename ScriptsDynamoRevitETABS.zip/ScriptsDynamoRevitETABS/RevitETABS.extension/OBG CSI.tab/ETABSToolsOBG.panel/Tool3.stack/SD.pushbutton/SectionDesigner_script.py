# -*- coding: utf-8 -*-
import sys
import clr

from pyrevit import forms
from Autodesk.Revit.DB import *
from Autodesk.Revit.DB.Structure import *
from Autodesk.Revit.UI.Selection import *

uiapp = __revit__
app = __revit__.Application 
uidoc = __revit__.ActiveUIDocument
doc = __revit__.ActiveUIDocument.Document

from enum import Enum
clr.AddReference("System")
import System
 
clr.AddReferenceToFileAndPath("C:\Program Files\Computers and Structures\ETABS 22\ETABSv1.dll")
from ETABSv1 import *
 
#create API helper object
helper = Helper()
# Intentar obtener el archivo ETABS abierto
try:
    myETABSObject = helper.GetObject("CSI.ETABS.API.ETABSObject") 
except:
    print("No se encontró ninguna instancia en ejecución de ETABS.")
    sys.exit(-1)


# Del objeto ETABS, obtenemos el objeto sapModel
SapModel = myETABSObject.SapModel
#print(SapModel.GetModelFilename())

# Añadir material ASTM A706
Name = ""
ret = SapModel.PropMaterial.AddQuick(Name, 7, None, None, None, None, 2)
print(ret)
# Añadir una nueva propiedad de sección del diseñador de secciones
ret = SapModel.PropFrame.SetSDSection("SD122", "A36")

print(ret)
"""
floatRef = 0.0
intRef = 1
stringRef = ""
boolRef = True
arrayFloat = System.Array[float]([])
arrayInt = System.Array[int]([])
arrayString = System.Array[str]([])
arrayBool = System.Array[bool]([])

nameCaseDead = "MUERTA"
nameCaseLive = "VIVA"
# 2. Obtenemos puntos seleccionados####################################################################################
puntosSeleccionadas = []
ret,numberItems,objectType,objectName = SapModel.SelectObj.GetSelected(intRef, arrayInt, arrayString)
for tipo, name in zip(objectType,objectName):
    if tipo == 1: # Se trata de punto
        puntosSeleccionadas.append(name)
ret = SapModel.SelectObj.ClearSelection()
if len(puntosSeleccionadas) == 0:
    forms.alert('No hay puntos seleccionados en el modelo ETABS.', exitscript=True)

# 3. Seleccionamos caso de carga
ret = SapModel.SetPresentUnits(eUnits.Ton_m_C)
ret = SapModel.Results.Setup.DeselectAllCasesAndCombosForOutput()
ret = SapModel.Results.Setup.SetCaseSelectedForOutput(nameCaseDead)
ret = SapModel.Results.Setup.SetCaseSelectedForOutput(nameCaseLive)

# 4. Obtenemos las reacciones de los puntos seleccionados D+L
reacc_Z_Dead = 0
reacc_Z_Live = 0
for punto in puntosSeleccionadas:
    [ret, NumberResults, 
    Obj, Elm, LoadCase,
    StepType, StepNum, 
    F1, F2, F3, M1, 
    M2, M3] = SapModel.Results.JointReact(punto, eItemTypeElm.Element, intRef, 
                                         arrayString, arrayString, arrayString, arrayString, 
                                         arrayFloat, arrayFloat, arrayFloat, arrayFloat,
                                         arrayFloat, arrayFloat, arrayFloat)
    for lc, val in zip(LoadCase, F3):
        if lc == nameCaseDead:
            reacc_Z_Dead += val
        if lc == nameCaseLive:
            reacc_Z_Live += val
#print("Carga muerta ", reacc_Z_Dead)
#print("Carga viva ", reacc_Z_Live)
cargaDL = reacc_Z_Dead + reacc_Z_Live
#print(cargaDL)

# 5. Obtener el suelo para almacenar la carga D+L
class filtroSeleccionMuros(ISelectionFilter):
  def AllowElement(self, element):
    return isinstance(element, Floor)
with forms.WarningBar(title='Seleccione un suelo o cimentacion tipo losa'):
    ref_Suelo = uidoc.Selection.PickObject(ObjectType.Element, filtroSeleccionMuros(), "Seleccione suelo")
    suelo = doc.GetElement(ref_Suelo)

# 6. Guardar en el parametro establecido
trans = Transaction(doc, "Crear suelo con offset")
trans.Start()
suelo.LookupParameter("OBG_CargaCimentacion").Set(cargaDL * 32174.0486)
trans.Commit()

"""