# -*- coding: utf-8 -*-
#https://forum.dynamobim.com/t/etabs-19-import-comtypes-client-issue/61409/6
import os
import sys
import clr

from enum import Enum
clr.AddReference("System")
import System
 
#set the following path to the installed SAP2000 program directory
clr.AddReferenceToFileAndPath("C:\Program Files\Computers and Structures\ETABS 18\ETABSv1.dll")

from ETABSv1 import *
 
#create API helper object
helper = Helper()
# Intentar obtener el archivo ETABS abierto
try:
    myETABSObject = helper.GetObject("CSI.ETABS.API.ETABSObject") 
except:
    print("No running instance of the program found or failed to attach.")
    sys.exit(-1)

"""
attributes = dir(myETABSObject)
for attr in attributes:
    print(attr)
"""

# Del objeto ETABS, obtenemos el objeto sapModel
SapModel = myETABSObject.SapModel
print(SapModel.GetModelFilename())
