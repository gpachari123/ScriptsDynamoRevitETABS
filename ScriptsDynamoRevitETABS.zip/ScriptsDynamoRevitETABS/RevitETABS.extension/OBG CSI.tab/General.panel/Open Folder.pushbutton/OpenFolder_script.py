# -*- coding: utf-8 -*-
import sys
import os

# Obtener la ruta completa del script actual
ruta_del_script = os.path.abspath(__file__)

# Obtener la carpeta donde se encuentra el script
carpeta_del_script = os.path.dirname(ruta_del_script)
carpeta_del_script.split(".tab")[0]

# Define la ruta de la carpeta que deseas abrir
#ruta_carpeta = r"E:\OneDrive\Gerald\13Dynamo\Ejemplos Ilustrativos\PyRevitExtensiones\Tools.extension\OBGStructure.tab"  # Reemplaza con la ruta que desees
ruta_carpeta = carpeta_del_script.split(".tab")[0] + ".tab"
# Usa el comando 'start' de Windows para abrir la carpeta en el explorador de archivos
os.startfile(ruta_carpeta)