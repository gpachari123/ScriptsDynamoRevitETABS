# -*- coding: utf-8 -*-
#______________________________ IMPORTS
import sys
from pyrevit import forms


from Autodesk.Revit.DB import *
from Autodesk.Revit.UI import *
from Autodesk.Revit.UI.Selection import *
# Variables basicas de Revit
uiapp = __revit__
app = __revit__.Application 
uidoc = __revit__.ActiveUIDocument
doc = __revit__.ActiveUIDocument.Document

# .NET IMPORTS
import clr

from datetime import datetime
from clr import AddReference
clr.AddReference('System.Windows.Forms')
clr.AddReference('System.Drawing')
from System.Windows.Forms import SaveFileDialog, DialogResult

import os

AddReference("System")
from System.Diagnostics.Process import Start
from System.Windows.Window import DragMove
from System.Windows.Input import MouseButtonState
from enum import Enum

AddReference("System")
import System
# Import ETABS
clr.AddReferenceToFileAndPath("C:\Program Files\Computers and Structures\ETABS 18\ETABSv1.dll")
from ETABSv1 import *

# Función para preguntar por la ruta de un archivo con extensión .e2k
def obtener_ruta_archivo(nombre_por_defecto="archivo_por_defecto.e2k"):
    save_dialog = SaveFileDialog()
    save_dialog.Filter = "Archivos E2K (*.e2k)|*.e2k"  # Filtrar solo archivos .e2k
    save_dialog.DefaultExt = "e2k"  # Establecer .e2k como extensión por defecto
    save_dialog.AddExtension = True  # Asegurar que la extensión se añade automáticamente
    save_dialog.FileName = nombre_por_defecto  # Asignar el nombre por defecto al archivo
    
    result = save_dialog.ShowDialog()
    
    if result == DialogResult.OK:
        return save_dialog.FileName
    return None

# Función para guardar información en el archivo .e2k
def guardar_informacion(ruta_archivo, informacion):
    if ruta_archivo:
        with open(ruta_archivo, 'w') as archivo:
            archivo.write(informacion)
        TaskDialog.Show("Correcto", "Información guardada en: {}".format(ruta_archivo))
    else:
        TaskDialog.Show("Error","No se seleccionó ningún archivo.")

# Funciones
def ObtenerNiveles(doc):
    niveles = FilteredElementCollector(doc).OfClass(Level).ToElements()
    niveles = sorted(niveles, key=lambda x: x.Elevation)
    return niveles

# Funcion para la altura de nivel
def AlturaNivel(nivel):
    elevAbso = nivel.Elevation
    puntos = FilteredElementCollector(doc).OfClass(BasePoint).ToElements() 	
    for p in puntos:
        if p.IsShared:
            pr=p.Position
        if not p.IsShared:
            pb=p.Position
    referencia = doc.GetElement(nivel.GetTypeId()).get_Parameter(BuiltInParameter.LEVEL_RELATIVE_BASE_TYPE).AsInteger()
    if referencia == 1:
        elevAbso = elevAbso + pr.Z
    if referencia == 0:
        elevAbso = elevAbso + pb.Z
    return elevAbso*0.3048

# Funcion para ensamblar el archivo E2K
def EnsamblarE2K(niveles, rejillas, ruta):
    # Obtener la ruta del directorio donde está el archivo .py actual
    ruta_actual = os.path.dirname(__file__)
    # Construir la ruta completa hacia 'plantilla.txt'
    ruta_archivo = os.path.join(ruta_actual, 'plantilla.txt')
    # Leer el archivo y mostrar su contenido
    with open(ruta_archivo, 'r') as archivo:
        contenido = archivo.read()

    # 1. Ediciones de nombre y titulos
    fecha = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
    titulo = doc.Title
    contenido = contenido.replace('{{ruta}}', ruta)
    contenido = contenido.replace('{{fecha}}', fecha)
    contenido = contenido.replace('{{titulo}}', titulo)

    # 2. Edicion de niveles y rejillas
    niveles = sorted(niveles, key=lambda x: x.Elevation, reverse=True)
    # Edicion de niveles
    textoNiveles = ''
    for i in range(len(niveles)-1):
        nivel = niveles[i]
        nombre = nivel.Name
        altura = AlturaNivel(niveles[i]) - AlturaNivel(niveles[i+1])
        textoNiveles += "  STORY \"{0}\" HEIGHT {1} MASTERSTORY \"Yes\"\n".format(nombre, altura)
    textoNiveles += "  STORY \"Base\" ELEV {0}\n".format(AlturaNivel(niveles[len(niveles)-1]))
    contenido = contenido.replace('{{niveles}}', textoNiveles)

    # Edicion de rejillas
    textoRejillas = ''
    for rejilla in rejillas:
        nombre = rejilla.Name
        # La línea es invertida en grillas
        x1 = rejilla.Curve.GetEndPoint(1).X * 0.3048
        y1 = rejilla.Curve.GetEndPoint(1).Y * 0.3048
        x2 = rejilla.Curve.GetEndPoint(0).X * 0.3048
        y2 = rejilla.Curve.GetEndPoint(0).Y * 0.3048
        textoRejillas += "GENGRID \"GLOBAL\"  LABEL \"{0}\"  X1 {1} Y1 {2} X2 {3} Y2 {4} VISIBLE \"Yes\"  BUBBLELOC \"End\"\n".format(nombre, x1, y1, x2, y2)
    contenido = contenido.replace('{{grillas}}', textoRejillas)

    # 3. Ubicacion espectro y factores de MassSorce
    factorCM = 1.00
    factorCV = 0.25
    rutaEspectroX = os.path.join(ruta, 'ESPXX.txt')
    rutaEspectroY = os.path.join(ruta, 'ESPXX.txt')

    contenido = contenido.replace('{{factorCM}}', (str)(factorCM))
    contenido = contenido.replace('{{factorCV}}', (str)(factorCV))
    contenido = contenido.replace('{{rutaEspectroX}}', rutaEspectroX)
    contenido = contenido.replace('{{rutaEspectroY}}', rutaEspectroY)

    # 4. Nro Modos y amplificaciones del casoDrift
    maxModes = (len(niveles) - 1) *3 if len(niveles) > 0 else 3
    amplSismoEscaladoX = 1
    amplSismoEscaladoX = 1
    amplDriftX = 1
    amplDriftY = 1

    contenido = contenido.replace('{{maxModes}}', (str)(maxModes))
    contenido = contenido.replace('{{factorSX}}', (str)(9.81))
    contenido = contenido.replace('{{factorSY}}', (str)(9.81))
    contenido = contenido.replace('{{amplSismoEscaladoX}}', (str)(amplSismoEscaladoX))
    contenido = contenido.replace('{{amplSismoEscaladoY}}', (str)(amplSismoEscaladoX))
    contenido = contenido.replace('{{amplDriftX}}', (str)(amplDriftX))
    contenido = contenido.replace('{{amplDriftY}}', (str)(amplDriftY))
    #print(contenido)
    return contenido

# Clase para objeto del listBox
class CheckableItem:
    def __init__(self, nivel):
        self.name = nivel.Name
        self.Nivel = nivel
        self.is_checked = False
    @property
    def Name(self):
        return self.name
    @property
    def IsChecked(self):
        return self.is_checked
    @IsChecked.setter
    def IsChecked(self, value):
        self.is_checked = value

# Formulario
class MyWindow(forms.WPFWindow):
    """GUI"""
    def __init__(self, xaml_file_name, niveles, nombreProyecto):
        self.form = forms.WPFWindow.__init__(self, xaml_file_name)
        self.main_title.Text = "Exportar E2K"
        self.TitleProyecto = nombreProyecto
        # Crear una lista de ítems CheckableItem desde los niveles
        self.items = [CheckableItem(nivel) for nivel in niveles]
        # Asignar la lista al ListBox
        self.lista_Niveles.ItemsSource = self.items
    @property
    def loadCase(self):
        return self.cmb_Casos.SelectedItem
        
    @property
    def carga(self):
        try:
            return float(self.input_carga.Text)
        except:
            print("input_carga debe ser numero!")


    # GUI EVENT HANDLERS:
    def btn_Examinar(self,sender,e):
        ruta_carpeta = obtener_ruta_archivo(self.TitleProyecto)
        try:
            self.txt_Ruta.Text = ruta_carpeta
        except:
            pass
        #print(ruta_carpeta)

    def button_close(self,sender,e):
        """Stop application by clicking on a <Close> button in the top right corner."""
        self.Close()

    def Hyperlink_RequestNavigate(self, sender, e):
        """Forwarding for a Hyperlink"""
        Start(e.Uri.AbsoluteUri)

    def header_drag(self,sender,e):
        """Drag window by holding LeftButton on the header."""
        if e.LeftButton == MouseButtonState.Pressed:
            DragMove(self)

    def button_run(self, sender, e):
        """Button action: Rename view with given """
        self.niveles_seleccionados = [item for item in self.lista_Niveles.ItemsSource if item.IsChecked]
        
        self.Close()

    def button_select_none(self, sender, e):
        # Seleccionar todos los ítems
        for item in self.items:
            item.IsChecked = False
        # Actualizar la vista del ListBox
        self.lista_Niveles.Items.Refresh()
    def button_select_all(self, sender, e):
        # Seleccionar todos los ítems
        for item in self.items:
            item.IsChecked = True
        # Actualizar la vista del ListBox
        self.lista_Niveles.Items.Refresh()






if __name__ == '__main__':
    niveles = ObtenerNiveles(doc)
    if len(niveles) == 0:
        TaskDialog.Show("Error", "No hay niveles en el proyecto")
        sys.exit()
    # Mostramos el formulario para que el usuario seleccione niveles
    form = MyWindow("ExportarE2K1.xaml", niveles, doc.Title)
    form.ShowDialog()
    try:
        nivelesSel = [niv.Nivel for niv in form.niveles_seleccionados]
    except:
        sys.exit()
    if len(nivelesSel) == 0:
        TaskDialog.Show("Error", "No hay niveles seleccionados")
        sys.exit()
    # Recuperamos las rejillas
    grillas = FilteredElementCollector(doc).OfClass(Grid).ToElements()
    grillasIds = [grid.Id for grid in grillas if isinstance(grid.Curve, Line)]
    multisegmento = FilteredElementCollector(doc).OfClass(MultiSegmentGrid).ToElements()
    grillasIdsMulti = []
    for multiGrid in multisegmento:
        grillasIdsMulti += multiGrid.GetGridIds()

    gridIds = [id for id in grillasIds if id not in grillasIdsMulti]
    grillas = [doc.GetElement(id) for id in gridIds]
    # Ensamblamos el archivo S2K
    contenido = EnsamblarE2K(nivelesSel, grillas, form.txt_Ruta.Text)
    guardar_informacion(form.txt_Ruta.Text, contenido)
