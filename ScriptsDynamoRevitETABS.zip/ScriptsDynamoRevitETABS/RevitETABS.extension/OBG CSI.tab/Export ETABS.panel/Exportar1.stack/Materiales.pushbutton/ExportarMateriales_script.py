# -*- coding: utf-8 -*-
#______________________________ IMPORTS
import sys
from pyrevit import forms


from Autodesk.Revit.DB import *
from Autodesk.Revit.DB.Structure import *
from Autodesk.Revit.UI import *
from Autodesk.Revit.UI.Selection import *
# Variables basicas de Revit
uiapp = __revit__
app = __revit__.Application 
uidoc = __revit__.ActiveUIDocument
doc = __revit__.ActiveUIDocument.Document

# .NET IMPORTS
import clr

from datetime import datetime
from clr import AddReference
clr.AddReference('System.Windows.Forms')
clr.AddReference('System.Drawing')
from System.Windows.Forms import SaveFileDialog, DialogResult


clr.AddReference('PresentationFramework')

from System.Windows import MessageBox
from System.Windows import MessageBoxButton, MessageBoxImage

import os

AddReference("System")
from System.Diagnostics.Process import Start
from System.Windows.Window import DragMove
from System.Windows.Input import MouseButtonState
from enum import Enum

AddReference("System")
import System
# Import ETABS
clr.AddReferenceToFileAndPath("C:\Program Files\Computers and Structures\ETABS 18\ETABSv1.dll")
from ETABSv1 import *



# Funcion para obtener los materiales de barras y panels
def MaterialesBarrasPanels(doc):
    barras = FilteredElementCollector(doc).OfClass(AnalyticalMember).ToElements()
    materialesBarras = [doc.GetElement(barra.MaterialId) for barra in barras]
    materialesBarras = [mat for mat in materialesBarras if mat is not None]

    paneles = FilteredElementCollector(doc).OfClass(AnalyticalPanel).ToElements()
    materialesPanels = [doc.GetElement(panel.MaterialId) for panel in paneles]
    materialesPanels = [mat for mat in materialesPanels if mat is not None]
    return materialesBarras + materialesPanels

# Funcion para crear material en ETABS
def CrearMaterialConcreto(modeloSap, nombre, densidades_kgf_m3, modulosElasticidad_kg_cm2, modulosPoisson, coefExpTerms_inv_C, fc_kg_cm2):
    ret = modeloSap.PropMaterial.SetMaterial(nombre, eMatType.Concrete)
    opcionDensidad = 1
    ret = modeloSap.PropMaterial.SetWeightAndMass(nombre, opcionDensidad, densidades_kgf_m3)
    # Cambiar propiedades isotropicas de material
    if modulosPoisson < 0.5:
        # cambiar unidades para la asignacion de propiedades
        ret = modeloSap.SetPresentUnits_2(eForce.kgf, eLength.cm, eTemperature.C)
        ret = modeloSap.PropMaterial.SetMPIsotropic(nombre, 
                                                    modulosElasticidad_kg_cm2, 
                                                    modulosPoisson, coefExpTerms_inv_C)
        # Devolver las unidades despues de la asignacion de propiedades
        ret = modeloSap.SetPresentUnits_2(eForce.kgf, eLength.m, eTemperature.C)

    # Modificar propiedades de material tipo concreto (propiedades de diseño)
    opcionStressStrainCurve = 1 #0,1,2
    opcionStressStrainCurveHys = 2 #0,1,2,3,4,5,6,7
    strainAtfc = 0.002 #<------------------------no usado
    strainUltimate = 0.0052 #<------------------------no usado
    # cambiar unidades para la asignacion de propiedades
    ret = modeloSap.SetPresentUnits_2(eForce.kgf, eLength.cm, eTemperature.C);
    # en esta ultima parte solo se usara los tres primeros parametros, los demas corresponden a datos de no linealidad
    ret = modeloSap.PropMaterial.SetOConcrete(nombre, fc_kg_cm2, False, 0, opcionStressStrainCurve, 
                                              opcionStressStrainCurveHys, strainAtfc, strainUltimate)
    ret = modeloSap.SetPresentUnits_2(eForce.kgf, eLength.m, eTemperature.C)

# Funcion para determinar si un material tiene propiedades validas
def EsMaterialRevitUsable(doc, material):
    materialStructural = doc.GetElement(material.StructuralAssetId)
    asset = materialStructural.GetStructuralAsset()
    if asset is None:
        return False
    clase = asset.StructuralAssetClass
    clasesAceptadas = [StructuralAssetClass.Metal, 
                       StructuralAssetClass.Concrete, 
                       StructuralAssetClass.Wood]
    if clase in clasesAceptadas:
        return True
    return False


# Funcion para crear material de Revit a ETABS
def EnviarMaterialRevitETABS(modeloSap, doc, materialRevit):
    if not EsMaterialRevitUsable(doc, materialRevit):
        return (False, "{}\tMaterial sin propiedades físicas".format(materialRevit.Name))
    
    materialStructural = doc.GetElement(materialRevit.StructuralAssetId)
    nombre = materialStructural.Name
    asset = materialStructural.GetStructuralAsset()
    densidad = asset.Density * 35.31466672;  # ejemplo de porque es mejor esta forma
    moduloElasticidad = asset.YoungModulus.X * 0.00003345526
    moduloPoisson = asset.PoissonRatio.X
    coefExpTerm = asset.ThermalExpansionCoefficient.X
    clase = asset.StructuralAssetClass
    comprConcret = asset.ConcreteCompression * 0.00003345526
    if clase == StructuralAssetClass.Concrete: # Solo funciona para el concreto
        CrearMaterialConcreto(modeloSap, nombre, densidad, moduloElasticidad, moduloPoisson, coefExpTerm, comprConcret)
    else:
        return (False, "{}\tMaterial no habilitado aun para exportación ETABS".format(nombre))
    return (True, "Correcto")


if __name__ == '__main__':
    helper = Helper()
    # Intentar obtener el archivo ETABS abierto
    try:
        myETABSObject = helper.GetObject("CSI.ETABS.API.ETABSObject") 
    except:
        pass
    if myETABSObject == None:
        MessageBox.Show("No se encontró ninguna instancia en ejecución de ETABS.", "Advertencia", MessageBoxButton.OK, MessageBoxImage.Error)
        sys.exit(-1)
    SapModel = myETABSObject.SapModel
    
    # 1. Obtenemos la lista de materiales unicos
    materiales = MaterialesBarrasPanels(doc)
    ids_vistos = set()  # Usamos un set para almacenar los Ids encontrados
    lista_sin_duplicados = []
    for mat in materiales:
        if mat.Id not in ids_vistos:
            lista_sin_duplicados.append(mat)
            ids_vistos.add(mat.Id)
    if len(lista_sin_duplicados) == 0:
        MessageBox.Show("No se han encontrado materiales en el modelo Analitico", "Error", MessageBoxButton.OK, MessageBoxImage.Error)
        sys.exit(-1)
    # 2. Creamos materiales en ETABS
    log = ""
    materialesExportados = []
    for material in lista_sin_duplicados:
        result = EnviarMaterialRevitETABS(SapModel, doc, material)
        if not result[0]:
            log += "\n{}".format(result[1])
        else:
            materialesExportados.append(material)
    
    # 3. Enviamos el mensaje final
    if len(materialesExportados) == 0:
        MessageBox.Show("No se ha exportado Ningun Material!\n" + log, "Error", MessageBoxButton.OK, MessageBoxImage.Error)
        sys.exit(-1)
    mensajeFinal = "Materiales Exportados:\n"
    for material in materialesExportados:
        mensajeFinal += "- {} \n".format(material.Name)
    if log != "":
        mensajeFinal += "Materiales con error:\n" + log
    MessageBox.Show(mensajeFinal, "Correcto", MessageBoxButton.OK, MessageBoxImage.Information)