# -*- coding: utf-8 -*-
#______________________________ IMPORTS
import sys
from pyrevit import forms


from Autodesk.Revit.DB import *
from Autodesk.Revit.DB.Structure import *
from Autodesk.Revit.UI import *
from Autodesk.Revit.UI.Selection import *
# Variables basicas de Revit
uiapp = __revit__
app = __revit__.Application 
uidoc = __revit__.ActiveUIDocument
doc = __revit__.ActiveUIDocument.Document

# .NET IMPORTS
import clr

from datetime import datetime
from clr import AddReference
clr.AddReference('System.Windows.Forms')
clr.AddReference('System.Drawing')
from System.Windows.Forms import SaveFileDialog, DialogResult


clr.AddReference('PresentationFramework')

from System.Windows import MessageBox
from System.Windows import MessageBoxButton, MessageBoxImage

import os

AddReference("System")
from System.Diagnostics.Process import Start
from System.Windows.Window import DragMove
from System.Windows.Input import MouseButtonState
from enum import Enum

AddReference("System")
import System
# Import ETABS
clr.AddReferenceToFileAndPath("C:\Program Files\Computers and Structures\ETABS 18\ETABSv1.dll")
from ETABSv1 import *

# Importacion de funciones geometricas
sys.path.append(r"E:\OneDrive\Gerald\13Dynamo\Ejemplos Ilustrativos\PyRevitExtensiones\funciones")
import funcionesGeometricas as funcs





# Valores por referencia para ETABS
ref_float = 0.0
ref_int = 1
ref_string = ""
ref_bool = True
ref_arrayFloat = System.Array[float]([])
ref_arrayInt = System.Array[int]([])
ref_arrayString = System.Array[str]([])
ref_arrayBool = System.Array[bool]([])




# Funcion para ver si dos double son iguales
def IsAlmostEqual(valor1, valor2, tolerancia=1e-6):
    return abs(valor1 - valor2) < tolerancia


# Funcion para obtener la interseccion de solido con plano
def IntersectPlaneSolid(solid, plane):
    cast = BooleanOperationsUtils.CutWithHalfSpace(solid, plane)
    for face in cast.Faces:
        if not isinstance(face, PlanarFace):
            continue
        if face.FaceNormal.IsAlmostEqualTo(plane.Normal.Negate()):
            CutFace = face
    if CutFace == None: return None
    #boundary= CutFace.GetEdgesAsCurveLoops()
    #return boundary[0]
    return CutFace

# Funcion para averiguar si un FamilyInstance es Rectangular
def EsFamilyInstanceRectangular(fi, esViga = False):
    ancho = 0.0
    alto = 0.0
    if fi is None:
        return (False, ancho, alto)
    solido = funcs.SolidoElemento(fi)
    dir1 = fi.HandOrientation
    dir2 = fi.FacingOrientation
    trans_fi = Transform.Identity
    trans_fi.Origin = solido.ComputeCentroid()
    trans_fi.BasisX = dir1
    trans_fi.BasisY = dir2
    trans_fi.BasisZ = dir1.CrossProduct(dir2)
    # Transformamos a coordenadas locales de origen
    solidoLocal_fi = SolidUtils.CreateTransformed(solido, trans_fi.Inverse)
    bb_fi = solidoLocal_fi.GetBoundingBox()
    minPoint = bb_fi.Transform.OfPoint(bb_fi.Min)
    maxPoint = bb_fi.Transform.OfPoint(bb_fi.Max)
    # Obtenemos las dimensiones Ancho y alto
    ancho = maxPoint.X - minPoint.X
    alto = maxPoint.Y - minPoint.Y
    if esViga:
        ancho = maxPoint.Y - minPoint.Y
        alto = maxPoint.Z - minPoint.Z
    # Verificamos si el surface del centro tiene area Rectangular
    plane = Plane.CreateByNormalAndOrigin(XYZ.BasisZ, XYZ(0,0,0))
    if esViga:
        plane = Plane.CreateByNormalAndOrigin(XYZ.BasisX, XYZ(0,0,0))
    sectionFace = IntersectPlaneSolid(solidoLocal_fi, plane)
    area = ancho * alto
    return (IsAlmostEqual(sectionFace.Area, area), ancho*0.3048, alto*0.3048)

# Funcion para obtener nombre del material
def NombreMaterial(materialRevit):
    try:
        materialStructural = doc.GetElement(materialRevit.StructuralAssetId)
        nombre = materialStructural.Name
    except:
        nombre = materialRevit.Name
    return nombre

# Funcion para obtener el nombre de tipo
def NombreFamilySymbol(tipoRevit):
    param = tipoRevit.get_Parameter(BuiltInParameter.SYMBOL_NAME_PARAM)
    return param.AsString() if param is not None else str(tipoRevit.Id)

# Funcion para obtener la categoria "Columna" "Viga"
def CategoriaSeccion(tipoRevit):
    if tipoRevit.Category.Id == ElementId(-2001320): #Viga
        return "Viga"
    elif tipoRevit.Category.Id == ElementId(-2001330): #Columna
        return "Columna"
    return ""

# Funcion para Crear la seccion en ETABS
def CrearSeccionRectangularETABS(modeloSap, seccion, Width_m, Depth_m):
    ret = modeloSap.SetPresentUnits_2(eForce.kgf, eLength.m, eTemperature.C)
    ret = modeloSap.SetPresentUnits(eUnits.kgf_m_C)
    ret = modeloSap.PropFrame.SetRectangle(seccion.Name, seccion.NombreMaterial, Depth_m, Width_m)
    # Configuracion Rebar refuerzo
    coverTop=0.06; coverBot=0.06; TopLeftArea=0; TopRightArea=0; BotLeftArea=0; BotRightArea=0
    [ret, cantMat, listaMats] = modeloSap.PropMaterial.GetNameList(ref_int, ref_arrayString, eMatType.Rebar)
    if cantMat == 0:
        print("Error, no hay material rebar en el modelo ETABS")
        return
    nombreMatRebar = listaMats[0]
    if seccion.Categoria == "Viga":
        ret = modeloSap.PropFrame.SetRebarBeam(seccion.Name, nombreMatRebar, nombreMatRebar,
        coverTop, coverBot, TopLeftArea, TopRightArea, BotLeftArea, BotRightArea)
    elif seccion.Categoria == "Columna":
        Pattern=2; ConfineType=2; Cover=0.06; NumberCBars=10; NumberR3Bars=0; NumberR2Bars=0
        TieSpacingLongit=0.04; Number2DirTieBars=0; Number3DirTieBars=0; ToBeDesigned=False
        RebarSize = "#5"; TieSize = "#3" # OJOOOOOO: Estos Rebars deben estar previamente definidos
        ret = modeloSap.PropFrame.SetRebarColumn(seccion.Name, nombreMatRebar, nombreMatRebar,
        Pattern, ConfineType, Cover, NumberCBars, NumberR3Bars, NumberR2Bars, 
        RebarSize, TieSize, TieSpacingLongit, Number2DirTieBars, Number3DirTieBars, ToBeDesigned)

# Funcion para determinar si una seccion de Revit es Rectangular
def EsSeccionRectangular(doc, seccion):
    ancho = 0.0
    alto = 0.0
    idTipoRevit = seccion.idTipoSec
    tipoRevit = doc.GetElement(idTipoRevit) if idTipoRevit is not None else None
    if tipoRevit is None:
        return (False, ancho, alto)
    
    # 1. Verificacion si hay forma de seccion
    formaSeccion = tipoRevit.get_Parameter(BuiltInParameter.STRUCTURAL_SECTION_SHAPE).AsInteger()
    if formaSeccion == 31:
        alto = tipoRevit.get_Parameter(BuiltInParameter.STRUCTURAL_SECTION_COMMON_HEIGHT).AsDouble()*0.3048
        ancho = tipoRevit.get_Parameter(BuiltInParameter.STRUCTURAL_SECTION_COMMON_WIDTH).AsDouble()*0.3048
        return (True, ancho, alto)
    
    # 2. Verificacion sin forma de seccion (Geometricamente)
    niveles = FilteredElementCollector(doc).OfClass(Level).ToElements()
    nivel = niveles[0] if len(niveles)>0 else None
    # Crear una instancia del elemento
    trans = Transaction(doc, "Creacion instancia temporal")
    trans.Start()
    linea = Line.CreateBound(XYZ(0,0,0), XYZ(10,10,10)) # Hacer una linea fuera de todos los elementos
    if seccion.Categoria == "Viga":
        instancia = doc.Create.NewFamilyInstance(linea, tipoRevit, nivel, StructuralType.Brace)
    elif seccion.Categoria == "Columna":
        instancia = doc.Create.NewFamilyInstance(linea, tipoRevit, nivel, StructuralType.Column)
    # Evaluar si la instancia es Rectangular
    result = EsFamilyInstanceRectangular(instancia, seccion.Categoria == "Viga")
    trans.RollBack()
    return result

# Clase para las secciones de barras
class Seccion:
    def __init__(self, doc, idTipoSec, idMaterial):
        self.idTipoSec = idTipoSec
        self.idMaterial = idMaterial
        tipo_sec = doc.GetElement(idTipoSec)
        self.NombreTipo = NombreFamilySymbol(tipo_sec) if tipo_sec is not None else None
        self.Categoria = CategoriaSeccion(tipo_sec) if tipo_sec is not None else ""
        material = doc.GetElement(idMaterial)
        self.NombreMaterial = NombreMaterial(material) if material is not None else None
        self.Name = "{} {}".format(self.NombreTipo, self.NombreMaterial) 
    # Sobrescribimos el método __eq__ para comparar dos objetos
    def __eq__(self, otro):
        # Verificamos si 'otro' es de la misma clase y comparamos sus atributos
        if isinstance(otro, Seccion):
            return self.idTipoSec == otro.idTipoSec and self.idMaterial == otro.idMaterial
        return False
    # Sobrescribimos __hash__ para garantizar consistencia en estructuras como set o dict
    def __hash__(self):
        return hash((self.idTipoSec, self.idMaterial))
    # Para imprimir el objeto de manera legible
    def __repr__(self):
        return "{}({}, {})".format(self.Categoria, self.NombreTipo, self.NombreMaterial)







if __name__ == '__main__':
    # 1. Obtener el modelo ETABS
    helper = Helper()
    # Intentar obtener el archivo ETABS abierto
    try:
        myETABSObject = helper.GetObject("CSI.ETABS.API.ETABSObject") 
    except:
        pass
    if myETABSObject == None:
        MessageBox.Show("No se encontró ninguna instancia en ejecución de ETABS.", "Advertencia", MessageBoxButton.OK, MessageBoxImage.Error)
        sys.exit(-1)
    SapModel = myETABSObject.SapModel
    # 2. Obtener las barras analiticasl del proyecto
    barras = FilteredElementCollector(doc).OfClass(AnalyticalMember).ToElements()
    # 3. Creamos los objetos secciones
    lista_Secciones = []
    for barra in barras:
        seccion = Seccion(doc, barra.SectionTypeId, barra.MaterialId)
        if not seccion in lista_Secciones:
            lista_Secciones.append(seccion)
    # 4. Iteramos sobre cada una se las secciones
    logSeccExportadas = ""
    log = ""
    seccionesExportadas = []
    for seccion in lista_Secciones:
        result = EsSeccionRectangular(doc, seccion)
        if seccion.idTipoSec == ElementId.InvalidElementId:
            log += "- {} : Seccion No Definida\n".format(seccion)
        elif seccion.idMaterial == ElementId.InvalidElementId:
            log += "- {} : Material No Definida\n".format(seccion)
        elif not result[0]: # No es seccion rectangular
            log += "- {} : No es una seccion rectangular\n".format(seccion)
        else:
            CrearSeccionRectangularETABS(SapModel, seccion, result[1], result[2])
            seccionesExportadas.append(seccion)

    # 5. Enviamos el mensaje final
    if len(seccionesExportadas) == 0:
        MessageBox.Show("No se ha exportado Ninguna Seccion!\n" + log, "Error", MessageBoxButton.OK, MessageBoxImage.Error)
        sys.exit(-1)
    mensajeFinal = "Materiales Exportados:\n"
    for secc in seccionesExportadas:
        mensajeFinal += "- {} \n".format(secc.Name)
    if log != "":
        mensajeFinal += "\nMateriales con error:\n" + log
    MessageBox.Show(mensajeFinal, "Correcto", MessageBoxButton.OK, MessageBoxImage.Information)
