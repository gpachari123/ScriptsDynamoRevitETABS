# -*- coding: utf-8 -*-
#______________________________ IMPORTS
import sys
from pyrevit import forms


from Autodesk.Revit.DB import *
from Autodesk.Revit.DB.Structure import *
from Autodesk.Revit.UI import *
from Autodesk.Revit.UI.Selection import *
# Variables basicas de Revit
uiapp = __revit__
app = __revit__.Application 
uidoc = __revit__.ActiveUIDocument
doc = __revit__.ActiveUIDocument.Document

# .NET IMPORTS
import clr

from datetime import datetime
from clr import AddReference
clr.AddReference('System.Windows.Forms')
clr.AddReference('System.Drawing')
from System.Windows.Forms import SaveFileDialog, DialogResult


clr.AddReference('PresentationFramework')

from System.Windows import MessageBox
from System.Windows import MessageBoxButton, MessageBoxImage

import os

AddReference("System")
from System.Diagnostics.Process import Start
from System.Windows.Window import DragMove
from System.Windows.Input import MouseButtonState
from enum import Enum

AddReference("System")
import System
# Import ETABS
clr.AddReferenceToFileAndPath("C:\Program Files\Computers and Structures\ETABS 18\ETABSv1.dll")
from ETABSv1 import *



# Valores por referencia para ETABS
ref_float = 0.0
ref_int = 1
ref_string = ""
ref_bool = True
ref_arrayFloat = System.Array[float]([])
ref_arrayInt = System.Array[int]([])
ref_arrayString = System.Array[str]([])
ref_arrayBool = System.Array[bool]([])




# Funcion para ver si dos double son iguales
def IsAlmostEqual(valor1, valor2, tolerancia=1e-6):
    return abs(valor1 - valor2) < tolerancia

# Funcion para obtener nombre del material
def NombreMaterial(materialRevit):
    try:
        materialStructural = doc.GetElement(materialRevit.StructuralAssetId)
        nombre = materialStructural.Name
    except:
        nombre = materialRevit.Name
    return nombre

# Funcion para obtener el nombre de tipo
def NombreFamilySymbol(tipoRevit):
    param = tipoRevit.get_Parameter(BuiltInParameter.SYMBOL_NAME_PARAM)
    return param.AsString() if param is not None else str(tipoRevit.Id)

# Funcion para obtener la categoria "Columna" "Viga"
def CategoriaSeccion(tipoRevit):
    if tipoRevit.Category.Id == ElementId(-2001320): #Viga
        return "Viga"
    elif tipoRevit.Category.Id == ElementId(-2001330): #Columna
        return "Columna"
    return ""

# Funcion para crear Wall en ETABS
def CrearSeccionWall(modeloSap, seccion, anchoMuro):
    ret = modeloSap.SetPresentUnits_2(eForce.kgf, eLength.m, eTemperature.C)
    tipoShell = eShellType.ShellThin
    ret = modeloSap.PropArea.SetWall(seccion.Name, eWallPropType.Specified, 
                                     tipoShell, seccion.NombreMaterial, anchoMuro)
    return ret == 0
    
def CrearSeccionSlab(modeloSap, seccion, anchoSlab):
    ret = modeloSap.SetPresentUnits_2(eForce.kgf, eLength.m, eTemperature.C)
    tipoSlab = eSlabType.Slab
    tipoShell = eShellType.ShellThin
    ret = modeloSap.PropArea.SetSlab(seccion.Name, tipoSlab, 
                                     tipoShell, seccion.NombreMaterial, anchoSlab)
    return ret == 0

def CrearSeccionSlabRibbed(modeloSap, nombreSeccion, nombreMat, overallDepth=0.20,
                           slabThickness=0.05, stemWidthAtTop=0.10, stemWidthAtBotton=0.10,
                           ribSpacing=0.40, ribsParallelTo=1):
    ret = modeloSap.SetPresentUnits_2(eForce.kgf, eLength.m, eTemperature.C)
    tipoSlab = eSlabType.Ribbed
    tipoShell = eShellType.ShellThin
    ret = modeloSap.PropArea.SetSlab(nombreSeccion, tipoSlab, tipoShell, nombreMat, overallDepth)
    ret += modeloSap.PropArea.SetSlabRibbed(nombreSeccion, overallDepth, slabThickness,
            stemWidthAtTop, stemWidthAtBotton, ribSpacing, ribsParallelTo)
    
    return ret == 0


# Clase para las secciones de Areas
class Seccion:
    def __init__(self, doc, analPanel):
        # Propiedad Principal FUNCION
        funcion_int = analPanel.StructuralRole
        if funcion_int == AnalyticalStructuralRole.Unset:
            self.Funcion = None
        elif funcion_int == AnalyticalStructuralRole.StructuralRolePanel:
            self.Funcion = None
        elif funcion_int == AnalyticalStructuralRole.StructuralRoleFloor: # Suelo
            self.Funcion = "Suelo"
        elif funcion_int == AnalyticalStructuralRole.StructuralRoleWall: #Muro
            self.Funcion = "Muro"
        # Propiedad Principal MATERIAL
        self.idMaterial = analPanel.MaterialId
        # Propiedad Principal GROSOR
        self.Grosor = analPanel.Thickness * 0.3048

        material = doc.GetElement(self.idMaterial)
        self.NombreMaterial = NombreMaterial(material) if material is not None else None
        # Ensamblamos el nombre
        self.Name = "{} {:.2f}m({})".format(self.Funcion, self.Grosor, self.NombreMaterial)
    # Sobrescribimos el método __eq__ para comparar dos objetos
    def __eq__(self, otro):
        # Verificamos si 'otro' es de la misma clase y comparamos sus atributos
        if isinstance(otro, Seccion):
            return self.Funcion == otro.Funcion and IsAlmostEqual(self.Grosor,otro.Grosor) and self.idMaterial == otro.idMaterial
        return False
    # Sobrescribimos __hash__ para garantizar consistencia en estructuras como set o dict
    def __hash__(self):
        return hash((self.idTipoSec, round(self.Grosor, 6), self.idMaterial))
    # Para imprimir el objeto de manera legible
    def __repr__(self):
        return self.Name

    def EsValidoParaExportar(self):
        if self.Funcion is None:
            return (False, "Seccion sin funcion asignada")
        if IsAlmostEqual(self.Grosor, 0.0):
            return (False, "Seccion con grosor nulo")
        if self.idMaterial == ElementId.InvalidElementId:
            return (False, "Seccion sin material asignada")
        return (True, "Correcto")

    def ExportarAETABS(self, modeloSap):
        if self.Funcion == "Suelo":
            return CrearSeccionSlab(modeloSap, self, self.Grosor)
        elif self.Funcion == "Muro":
            return CrearSeccionWall(modeloSap, self, self.Grosor)
        return False









if __name__ == '__main__':
    # 1. Obtener el modelo ETABS
    helper = Helper()
    # Intentar obtener el archivo ETABS abierto
    try:
        myETABSObject = helper.GetObject("CSI.ETABS.API.ETABSObject") 
    except:
        pass
    if myETABSObject == None:
        MessageBox.Show("No se encontró ninguna instancia en ejecución de ETABS.", "Advertencia", MessageBoxButton.OK, MessageBoxImage.Error)
        sys.exit(-1)
    SapModel = myETABSObject.SapModel
    # 2. Obtener los paneles analiticasl del proyecto
    paneles = FilteredElementCollector(doc).OfClass(AnalyticalPanel).ToElements()
    
    # 3. Creamos los objetos secciones
    lista_Secciones = []
    for panel in paneles:
        seccion = Seccion(doc, panel)
        if not seccion in lista_Secciones:
            lista_Secciones.append(seccion)
    
    # 4. Iteramos sobre cada una se las secciones
    logSeccExportadas = ""
    log = ""
    seccionesExportadas = []
    for seccion in lista_Secciones:
        resultEvaluar = seccion.EsValidoParaExportar()
        if resultEvaluar[0]:
            seccion.ExportarAETABS(SapModel)
            seccionesExportadas.append(seccion)
        else:
            log += "- {} : {}\n".format(seccion.Name, resultEvaluar[1])


    # 5. Enviamos el mensaje final
    if len(seccionesExportadas) == 0:
        MessageBox.Show("No se ha exportado Ninguna Seccion!\n" + log, "Error", MessageBoxButton.OK, MessageBoxImage.Error)
        sys.exit(-1)
    mensajeFinal = "Materiales Exportados:\n"
    for secc in seccionesExportadas:
        mensajeFinal += "- {} \n".format(secc.Name)
    if log != "":
        mensajeFinal += "\nMateriales con error:\n" + log
    MessageBox.Show(mensajeFinal, "Correcto", MessageBoxButton.OK, MessageBoxImage.Information)
    