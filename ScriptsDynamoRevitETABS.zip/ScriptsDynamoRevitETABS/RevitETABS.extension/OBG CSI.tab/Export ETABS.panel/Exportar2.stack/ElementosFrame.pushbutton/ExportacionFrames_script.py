# -*- coding: utf-8 -*-
#______________________________ IMPORTS
import sys
import math
from pyrevit import forms


from Autodesk.Revit.DB import *
from Autodesk.Revit.DB.Structure import *
from Autodesk.Revit.UI import *
from Autodesk.Revit.UI.Selection import *
# Variables basicas de Revit
uiapp = __revit__
app = __revit__.Application 
uidoc = __revit__.ActiveUIDocument
doc = __revit__.ActiveUIDocument.Document

# .NET IMPORTS
import clr

from datetime import datetime
from clr import AddReference
clr.AddReference('System.Windows.Forms')
clr.AddReference('System.Drawing')
from System.Windows.Forms import SaveFileDialog, DialogResult


clr.AddReference('PresentationFramework')

from System.Windows import MessageBox
from System.Windows import MessageBoxButton, MessageBoxImage

import os

AddReference("System")
from System.Diagnostics.Process import Start
from System.Windows.Window import DragMove
from System.Windows.Input import MouseButtonState
from enum import Enum

AddReference("System")
import System
# Import ETABS
clr.AddReferenceToFileAndPath("C:\Program Files\Computers and Structures\ETABS 18\ETABSv1.dll")
from ETABSv1 import *

# Importacion de funciones geometricas
sys.path.append(r"E:\OneDrive\Gerald\13Dynamo\Ejemplos Ilustrativos\PyRevitExtensiones\funciones")
import funcionesGeometricas as funcs





# Valores por referencia para ETABS
ref_float = 0.0
ref_int = 1
ref_string = ""
ref_bool = True
ref_arrayFloat = System.Array[float]([])
ref_arrayInt = System.Array[int]([])
ref_arrayString = System.Array[str]([])
ref_arrayBool = System.Array[bool]([])


# Funcion para verificar la verticalidad de una Line
def es_linea_vertical(linea):
    if not isinstance(linea, Line):
        return False
    # Obtener los puntos de inicio y fin de la línea
    punto_inicial = linea.GetEndPoint(0)
    punto_final = linea.GetEndPoint(1)
    # Verificar si las coordenadas X e Y son iguales, pero Z es diferente
    return punto_inicial.X == punto_final.X and punto_inicial.Y == punto_final.Y and punto_inicial.Z != punto_final.Z


# Dividir la línea vertical según los niveles
def dividir_linea_por_niveles(linea, niveles):
    segmentos = []
    punto_inicial = linea.GetEndPoint(0)
    punto_final = linea.GetEndPoint(1)
    # Crear una lista de alturas de los niveles que están dentro del rango de la línea
    alturas_niveles = [nivel.Elevation for nivel in niveles if punto_inicial.Z <= nivel.Elevation <= punto_final.Z]
    # Agregar las alturas de los extremos de la línea
    alturas_niveles.insert(0, punto_inicial.Z)
    alturas_niveles.append(punto_final.Z)
    # Dividir la línea en segmentos usando las alturas de los niveles
    for i in range(len(alturas_niveles) - 1):
        p1 = XYZ(punto_inicial.X, punto_inicial.Y, alturas_niveles[i])
        p2 = XYZ(punto_inicial.X, punto_inicial.Y, alturas_niveles[i + 1])
        try:
            segmento = Line.CreateBound(p1, p2)
            segmentos.append(segmento)
        except:
            pass
    return segmentos


# Funcion para Crear la seccion en ETABS
def FrameAddByLine(modeloSap, linea, nombre = None, refreshView = False):
    xi = linea.GetEndPoint(0).X * 0.3048
    yi = linea.GetEndPoint(0).Y * 0.3048
    zi = linea.GetEndPoint(0).Z * 0.3048
    xf = linea.GetEndPoint(1).X * 0.3048
    yf = linea.GetEndPoint(1).Y * 0.3048
    zf = linea.GetEndPoint(1).Z * 0.3048
    [ret, nombreAsignado] = modeloSap.FrameObj.AddByCoord(xi, yi, zi, xf, yf, zf, ref_string, "Default", "", "Global")
    #print(ret + " " + nombreAsignado)
    if refreshView:
        ret = modeloSap.View.RefreshView(0, False)
    if not nombre is None:
        ret = modeloSap.FrameObj.ChangeName(nombreAsignado, nombre)
        if ret == 0:
            return nombre
    return nombreAsignado

# Funcion para crear Cargas en ETABS
def LineLoadETABS(modeloSap, carga, eDirectionLoad = 6):
    if carga.IsHosted:
        id = doc.GetElement(carga.HostElementId).Category.Id
        if id == ElementId(-2009662):                
            w_inicial = -1 * math.fabs(carga.ForceVector1.Z * 0.101972086)
            w_final = -1 * math.fabs(carga.ForceVector2.Z * 0.101972086)
            nombreBarra = str(carga.HostElementId)
            loadPat = carga.LoadCase.Name
            distRel_inicial = 0.0
            distRel_final = 1.0
            relatDist = True
            CSys = "Global"
            replace = False
            if eDirectionLoad == 1 or eDirectionLoad == 2 or eDirectionLoad == 3:
                CSys = "Local"
            ret = modeloSap.FrameObj.SetLoadDistributed(nombreBarra, loadPat, 1, 
                    eDirectionLoad, distRel_inicial, distRel_final, w_inicial, w_final, 
                    CSys,relatDist, replace)
    



# Obtener los niveles del proyecto
def obtener_niveles(doc):
    niveles = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_Levels).WhereElementIsNotElementType().ToElements()
    return sorted(niveles, key=lambda nivel: nivel.Elevation)  # Ordenar los niveles por elevación






# Funcion para obtener nombre del material
def NombreMaterial(materialRevit):
    try:
        materialStructural = doc.GetElement(materialRevit.StructuralAssetId)
        nombre = materialStructural.Name
    except:
        nombre = materialRevit.Name
    return nombre

# Funcion para obtener el nombre de tipo
def NombreFamilySymbol(tipoRevit):
    param = tipoRevit.get_Parameter(BuiltInParameter.SYMBOL_NAME_PARAM)
    return param.AsString() if param is not None else str(tipoRevit.Id)

# Funcion para obtener la categoria "Columna" "Viga"
def CategoriaSeccion(tipoRevit):
    if tipoRevit.Category.Id == ElementId(-2001320): #Viga
        return "Viga"
    elif tipoRevit.Category.Id == ElementId(-2001330): #Columna
        return "Columna"
    return ""



# Clase para las secciones de barras
class Seccion:
    def __init__(self, doc, idTipoSec, idMaterial):
        self.idTipoSec = idTipoSec
        self.idMaterial = idMaterial
        tipo_sec = doc.GetElement(idTipoSec)
        self.NombreTipo = NombreFamilySymbol(tipo_sec) if tipo_sec is not None else None
        self.Categoria = CategoriaSeccion(tipo_sec) if tipo_sec is not None else ""
        material = doc.GetElement(idMaterial)
        self.NombreMaterial = NombreMaterial(material) if material is not None else None
        self.Name = "{} {}".format(self.NombreTipo, self.NombreMaterial) 
    # Sobrescribimos el método __eq__ para comparar dos objetos
    def __eq__(self, otro):
        # Verificamos si 'otro' es de la misma clase y comparamos sus atributos
        if isinstance(otro, Seccion):
            return self.idTipoSec == otro.idTipoSec and self.idMaterial == otro.idMaterial
        return False
    # Sobrescribimos __hash__ para garantizar consistencia en estructuras como set o dict
    def __hash__(self):
        return hash((self.idTipoSec, self.idMaterial))
    # Para imprimir el objeto de manera legible
    def __repr__(self):
        return "{}({}, {})".format(self.Categoria, self.NombreTipo, self.NombreMaterial)






if __name__ == '__main__':
    # 1. Obtener el modelo ETABS
    helper = Helper()
    # Intentar obtener el archivo ETABS abierto
    try:
        myETABSObject = helper.GetObject("CSI.ETABS.API.ETABSObject") 
    except:
        pass
    if myETABSObject == None:
        MessageBox.Show("No se encontró ninguna instancia en ejecución de ETABS.", "Advertencia", MessageBoxButton.OK, MessageBoxImage.Error)
        sys.exit(-1)
    SapModel = myETABSObject.SapModel
    # 2. Obtener las barras analiticasl del proyecto y clasificarlas
    barras = FilteredElementCollector(doc).OfClass(AnalyticalMember).ToElements()
    barrasVerticales = []
    barrasInclinadasHor = []
    barrasNoIncluidas = []
    for barra in barras:
        if es_linea_vertical(barra.GetCurve()):
            barrasVerticales.append(barra)
        elif isinstance(barra.GetCurve(), Line):
            barrasInclinadasHor.append(barra)
        else:
            barrasNoIncluidas.append(barra)

    # 3. Para las barras verticales creamos en ETABS
    count = 1
    total =len(barrasVerticales)
    with forms.ProgressBar(title='Creando Columnas') as pb:
        niveles = obtener_niveles(doc)
        for barra in barrasVerticales:
            seccion = Seccion(doc, barra.SectionTypeId, barra.MaterialId)
            lineaBarra = barra.GetCurve()
            lineasBarra = dividir_linea_por_niveles(lineaBarra, niveles)
            for linea in lineasBarra:
                nombreFrame = FrameAddByLine(SapModel, linea) # Se puede asignar nombre a los frames
                ret = SapModel.FrameObj.SetSection(nombreFrame, seccion.Name)
                anguloGiro_deg = barra.get_Parameter(BuiltInParameter.ANALYTICAL_MEMBER_ROTATION).AsDouble() * 180 / math.pi
                ret = SapModel.FrameObj.SetLocalAxes(nombreFrame, anguloGiro_deg)
                # Falta Insertion Point
            pb.update_progress(count, total)
            count += 1
        ret = SapModel.View.RefreshView(0, False)

    # 4. Para las barras inclinadas y horizontales
    count = 1
    total =len(barrasInclinadasHor)
    with forms.ProgressBar(title='Creando Vigas') as pb:
        for barra in barrasInclinadasHor:
            seccion = Seccion(doc, barra.SectionTypeId, barra.MaterialId)
            lineaBarra = barra.GetCurve()
            nombreFrame = FrameAddByLine(SapModel, lineaBarra, str(barra.Id)) # Se puede asignar nombre a los frames
            ret = SapModel.FrameObj.SetSection(nombreFrame, seccion.Name)
            pb.update_progress(count, total)
            count += 1
        ret = SapModel.View.RefreshView(0, False)

    # 5. Asignamos las cargas hospedades en vigas
    cargas = FilteredElementCollector(doc).OfClass(LineLoad).ToElements()
    count = 1
    total =len(cargas)
    with forms.ProgressBar(title='Asignando Cargas') as pb:
        for carga in cargas:
            LineLoadETABS(SapModel, carga)
            pb.update_progress(count, total)
            count += 1
            
    




    
    """
    # 3. Creamos los objetos secciones
    lista_Secciones = []
    for barra in barras:
        seccion = Seccion(doc, barra.SectionTypeId, barra.MaterialId)
        if not seccion in lista_Secciones:
            lista_Secciones.append(seccion)
    # 4. Iteramos sobre cada una se las secciones
    logSeccExportadas = ""
    log = ""
    seccionesExportadas = []
    for seccion in lista_Secciones:
        result = EsSeccionRectangular(doc, seccion)
        if seccion.idTipoSec == ElementId.InvalidElementId:
            log += "- {} : Seccion No Definida\n".format(seccion)
        elif seccion.idMaterial == ElementId.InvalidElementId:
            log += "- {} : Material No Definida\n".format(seccion)
        elif not result[0]: # No es seccion rectangular
            log += "- {} : No es una seccion rectangular\n".format(seccion)
        else:
            CrearSeccionRectangularETABS(SapModel, seccion, result[1], result[2])
            seccionesExportadas.append(seccion)

    # 5. Enviamos el mensaje final
    if len(seccionesExportadas) == 0:
        MessageBox.Show("No se ha exportado Ninguna Seccion!\n" + log, "Error", MessageBoxButton.OK, MessageBoxImage.Error)
        sys.exit(-1)
    mensajeFinal = "Materiales Exportados:\n"
    for secc in seccionesExportadas:
        mensajeFinal += "- {} \n".format(secc.Name)
    if log != "":
        mensajeFinal += "\nMateriales con error:\n" + log
    MessageBox.Show(mensajeFinal, "Correcto", MessageBoxButton.OK, MessageBoxImage.Information)
"""